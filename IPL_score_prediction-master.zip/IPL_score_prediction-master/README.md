# IPL_score_prediction
Predicting projected score of current innings of a cricket match after every 6 overs based on various parameters.
- final_model.ipynb only predicts projected scores based on basic parameters like venue, batsman, bowlers and total runs in those overs.
- Prediction using TF.ipynb used advanced paramters like player's career stats and used neural net for prediction

